Apologies for the ugly hierarchy,

but it HAS to be like this!

Uploads to captive portal www cannot have any subdirectories. 

Anything in the subdirectories are not added to cportal.

	--Dylan