/**
 * Created by Dylan @ Smartlaunch on 2/20/2015.
 */
var server = ["192.168.0.25", 7833];