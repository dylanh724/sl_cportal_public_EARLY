<?php
	##################################
	# by Edwin + Dylan @ Smartlaunch #
	##################################

	# GET >> Example >> http://192.168.0.25:7833/users/dylan
	if ( isset( $_GET["resturl"] ) ) {
		$url = $_GET["resturl"];

		if ( isset( $_GET["password"] ) ) {
		$url .= "&password=" . $_GET["password"];
		}

		# Success: GET response
		$service_url = $url;
		$curl = curl_init ( $service_url );
		curl_setopt ( $curl, CURLOPT_RETURNTRANSFER, true );
		$curl_response = curl_exec ( $curl );

		if ( $curl_response === false ) {
			$info = curl_getinfo ( $curl );
			curl_close ( $curl );
			die ( 'Error occurred during curl exec. Additional info: ' . var_export($info) );
		}
		curl_close ( $curl );
	} else {
		# Fail
		$curl_response = "Fail: Bad parameter?";
	}

	# SEND output
	echo ( $curl_response );

?>